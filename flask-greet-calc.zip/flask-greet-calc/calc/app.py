from flask import Flask
from flask import request
from operations import add, sub, mult, div

app = Flask(__name__)

"""Basic math operations."""

@app.route('/add')
def add_dir():
    """add a and b."""
    a = request.args["a"]
    b = request.args["b"]
    return f"{int(a)+int(b)}"

@app.route('/sub')
def sub_dir():
    """Substract b from a."""
    a = request.args["a"]
    b = request.args["b"]
    return f"{int(a)-int(b)}"

@app.route('/mult')
def mult_dir():
    """Multiply a and b."""
    a = request.args["a"]
    b = request.args["b"]
    return f"{int(a)*int(b)}"

@app.route('/div')
def div_dir():
    """Divide a by b."""
    a = request.args["a"]
    b = request.args["b"]
    return f"{int(a)/int(b)}"

operators = {
    "add": add,
    "sub": sub,
    "mult": mult,
    "div": div,
}

@app.route('/math/<oper>')
def operation(oper):
    """Get operation from url and apply operation on a by b (add/sub/mult/div)."""
    a = request.args["a"]
    b = request.args["b"]
    return f"{operators[oper](int(a), int(b))}"